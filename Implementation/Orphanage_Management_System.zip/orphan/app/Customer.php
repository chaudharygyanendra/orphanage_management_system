<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Customer extends Authenticatable
{
    protected $guard = 'customer';

    protected $fillable=['customer_name','customer_email','customer_mobile','customer_address','password','customer_status'];


    public function adapt(){
        return $this->hasMany('App\Adapt');
    }
}
