<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Donation;
use App\Child;
use App\Http\Requests\DonationRequest;


class FrontendController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        $childs=Child::where('child_status','active')->get();
        return view('frontend.index',compact('childs'));
    }

     public function adoption()
    {
        $childs=Child::where('child_status','active')->get();
        return view('frontend.adoption',compact('childs'));
    }

     public function about()
    {
        $childs=Child::where('child_status','active')->get();
        return view('frontend.about',compact('childs'));
    }

    public function singleChild($slug)
    {
        $child=Child::where('slug',$slug)->first();
        return view('frontend.adoption-single',compact('child'));
    }

    
    public function memberLogin()
    {
        return view('frontend.customer-login');
    }

    public function memberRegister()
    {
        return view('frontend.customer-register');
    }

    public function donation()
    {
        return view('frontend.donation');
    }
    public function contact()
    {
        return view('frontend.contact');
    }
    public function adoptionHowTo()
    {
        return view('frontend.adoption-how-to');
    }

    public function donationAdd(DonationRequest $request)
    {
        $result=Donation::create($request->all());
        return back()->with('success','Thank you for donating!');

    }
}
