<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Child;
use App\Http\Requests\ChildRequest;
use App\Http\Controllers\Controller;

class ChildController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $childs=Child::get();
        return view('backend.child.index',compact('childs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       return view('backend.child.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ChildRequest $request)
    {

        if(!empty($request->file('child_images'))){
            $child_image = $request->file('child_images');
            $extension = $child_image->getClientOriginalExtension();
            $imageName = 'child'. time(). '.' . $extension;
            $child_image->move('images/child/', $imageName);             
            $request['child_image'] = $imageName;
        }

            $result=Child::create($request->all());
        return redirect()->route('child.index')
                        ->with('success','Child added successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        try{
            $child = Child::find($id);
            return view('backend.child.edit', compact('child'));
        }catch (\Exception $e) {
            $exception = $e->getMessage();
            session()->flash('error', 'EXCEPTION :' . $exception);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ChildRequest $request, $id)
    {

        $child=Child::find($id);
        if($child){
       


        if(!empty($request->file('child_images'))){
            $child_image = $request->file('child_images');
            $extension = $child_image->getClientOriginalExtension();
            $imageName = 'child'. time(). '.' . $extension;
            $child_image->move('images/child/', $imageName);             
            $request['child_image'] = $imageName;
        }

            $child->update($request->all());
        return redirect(route('child.index'))
        ->with('success','Child info Update successfully!');
    }
    else{

                session()->flash('error','No record with given id!');
                return back();
            }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $res=Child::find($id)->delete();
        return redirect()->route('child.index')
        ->with('success','Child info deleted successfully!');

    }
    public function status($id)
    {
        $data=Child::find($id);
        
        if($data->child_status=='active')
        {
            $data->child_status='inactive';
            $data->save();
        }
        else{
            $data->child_status='active';
            $data->save();
        }
       return redirect()->route('child.index')
        ->with('success','Status has been changed successfully!');
       
    }

}
