<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Donation;
use App\Child;
use App\User;
use App\Customer;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $userCount=User::count();
        $childCount=Child::count();
        $customerCount=Customer::count();
        $donations=Donation::get();
        $totalAmount=collect($donations)->sum('amount');
        return view('backend.home',compact('userCount','childCount','customerCount','totalAmount'));
    }

    public function donationView()
    {
        $donations=Donation::get();
        $totalAmount=collect($donations)->sum('amount');

        return view('backend.donation.index',compact('donations','totalAmount'));
    }
}
