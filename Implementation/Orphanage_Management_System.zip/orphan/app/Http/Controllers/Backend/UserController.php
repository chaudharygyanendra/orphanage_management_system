<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Requests\PasswordRequest;
use App\Http\Requests\UserRequest;
use App\Http\Requests\UserUpdateRequest;
use App\Repository\UserRepository;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::all();
        return view('backend.users.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UserRequest $request)
    {
        try {
            $password = str_random(6);
            $request['password'] = bcrypt($password);

            $user = User::create($request->all());
            if ($user) {
                Mail::send('backend.users.email', ['userName' => $request->name, 'password' => $password], function ($m) use ($request) {
                    $m->to($request->email)->subject('User Access Information');
                });
                session()->flash('success', 'User Successfully Created');
                return back();

            } else {
                session()->flash('success', 'User could not be Create');
                return back();
            }

        } catch (\Exception $e) {
            return $e->getMessage();
            session()->flash('error', 'Exception : ' . $e);
            return back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
        public function edit($id)
    {
        try {
            $id = (int)$id;
            $edits = $this->userRepository->findById($id);
            if (count($edits) > 0) {
                $users = $this->userRepository->all();
                return view('backend.users.index', compact('users', 'edits'));
            } else {
                session()->flash('error', 'Id could not be obtained');
                return back();
            }

        } catch (\Exception $e) {
            $exception = $e->getMessage();
            session()->flash('error', 'EXCEPTION :' . $exception);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UserUpdateRequest $request, $id)
    {
        $id = (int)$id;
        try {
            $user = User::find($id);
            if ($user) {
                $update = $user->fill($request->all())->save();
                if ($update) {
                    session()->flash('success', 'User Successfully updated');
                    return redirect(route('user.index'));
                } else {
                    session()->flash('error', 'User could not be update');
                    return back();
                }
            }

        } catch (\Exception $e) {
            $exception = $e->getMessage();
            session()->flash('error', 'EXCEPTION:' . $exception);
            return back();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $id = (int)$id;
        try {
            $user = $this->userRepository->findById($id);
            if (User::destroy($id)) {
                session()->flash('success', 'User successfully deleted');
                return back();
            } else {
                session()->flash('error', 'User could not be deleted');
                return back();
            }

        } catch (\Exception $e) {
            $exception = $e->getMessage();
            session()->flash('error', 'EXCEPTION' . $exception);
            return back();

        }
    }

    public function status($id)
    {
        try {
            $id = (int)$id;
            $user = $this->userRepository->findById($id);
            if ($user->user_status == 'inactive')
            {
                $user->user_status = 'active';
                $user->save();
                session()->flash('success', 'User Successfully Activated');
                return back();
            }
            $user->user_status = 'inactive';
            $user->save();
            session()->flash('success', 'User Successfully Deactivated');
            return back();

        } catch (\Exception $e) {
            $message = $e->getMessage();
            session()->flash('error', $message);
            return back();
        }
    }

    public function password(PasswordRequest $request)
    {
        if (Hash::check($request->input('old'), Auth::user()->password)) {
            $id = Auth::user()->id;
            $data = $this->user->find($id);
            if ($data) {
                $request['password'] = Hash::make($request->input('password'));
                $data->fill($request->all())->save();
                session()->flash('success', 'Password was changed successfully.');
                return redirect()->back();
            }
            session()->flash('error', 'Error Occoured!!!! Something is not right.');
            return redirect()->back()->withInput();
        }
        session()->flash('error', 'Error Occoured!!!! Old password incorrect');
        return redirect()->back()->withInput();

    }
}
