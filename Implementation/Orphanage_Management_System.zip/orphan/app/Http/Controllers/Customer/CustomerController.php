<?php

namespace App\Http\Controllers\Customer;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Http\Controllers\Controller;

class CustomerController extends Controller
{
 
   public function __construct()
    {
         $this->middleware('auth:customer');
    }

    /**
     * show dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customer = Auth::guard('customer')->user();
        return view('customer.dashboard',compact('customer'));
    }

     public function profileView()
    {
        $customer = Auth::guard('customer')->user();
        return view('customer.profile',compact('customer'));
    }

    public function passwordView()
    {
        $customer = Auth::guard('customer')->user();
        return view('customer.password',compact('customer'));
    }

    public function passwordUpdate(PasswordRequest $request)
    {
        $customer = Auth::guard('customer')->user();
        if (Hash::check($request->input('old'),$customer->password)) {
            $id = $customer->id;
            $data = Customer::find($id);
            if ($data) {
                $request['password'] = Hash::make($request->input('password'));
                $data->fill($request->all())->save();
                session()->flash('success', 'Password was changed successfully!');
                return redirect()->back();
            }
            session()->flash('error', 'Error Occoured!!!! Something is not right!');
            return redirect()->back()->withInput();
        }
        session()->flash('error', 'Error Occoured!!!! Old password incorrect!');
        return redirect()->back()->withInput();
    }


    public function profileUpdate(CustomerProfileRequest $request)
    {
        $customer = Auth::guard('customer')->user();
        $customer->update($request->all());
            
        return back()
        ->with('success','Profile Update successfully!');
    }


}