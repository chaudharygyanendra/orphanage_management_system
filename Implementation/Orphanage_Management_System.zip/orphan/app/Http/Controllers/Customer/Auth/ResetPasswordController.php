<?php

namespace App\Http\Controllers\Employer\Auth;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\ResetsPasswords;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Auth;

class ResetPasswordController extends Controller
{


    use ResetsPasswords;

    protected $redirectTo = '/co/dashboard';


    public function showResetForm(Request $request, $token = null)
    {
        return view('employer.auth.passwords.reset')->with(
            ['token' => $token, 'email' => $request->email]
        );
    }

    public function broker()
    {
        return Password::broker('employers');
    }

    //returns authentication guard of seller
    protected function guard()
    {
        return Auth::guard('employer');
    }

}
