<?php

namespace App\Http\Controllers\Customer;

use App\Http\Requests\CustomerRequest;
use App\Customer;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Foundation\Auth\AuthenticatesUsers;


class CustomerLoginController extends Controller
{
     use AuthenticatesUsers;


    protected $redirectTo = '/customer/dashboard';
    protected $guard = 'customer';

    protected function guard()
    {
        return Auth::guard('customer');
    }

    public function __construct()
    {
        $this->middleware('guest')->except('logout');

    }

    public function username()
    {
        return 'customer_email';
    }

   

    public function login(Request $request)
    {

        if (Auth::guard('customer')->attempt(['customer_email' => $request->email, 'password' => $request->password,'customer_status' => 'active'], $request->remember)) {
            return redirect()->intended(route('customer.dashboard'));
        }
        return redirect()->back()->withInput($request->only('email', 'remember'));
    }

    


    public function register(CustomerRequest $request)
    {
        try {
            $password = $request->password;
            $request['password'] = bcrypt($password);
            $user = Customer::create($request->all());
                session()->flash('success', 'You are registered Successfully!');
            return back();

        } catch (\Exception $e) {
            return $e->getMessage();
            session()->flash('error', 'Exception : ' . $e);
            return back();
        }
    }

    public function logout(Request $request)
    {
        Auth::guard('customer')->logout();

        $request->session()->invalidate();

        return redirect('/');
    }

}