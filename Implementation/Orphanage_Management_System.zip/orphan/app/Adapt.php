<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Adapt extends Model
{
    protected $fillable=['customer_id','child_id'];

    public function customer(){
        return $this->belongsTo('App\Customer','customer_id','id');
    }

    public function child(){
        return $this->belongsTo('App\Child','child_id','id');
    }
}
