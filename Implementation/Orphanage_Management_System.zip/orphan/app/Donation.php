<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Donation extends Model
{
   protected $fillable=['first_name','last_name','contact','address','email','bank_associated','bank_account_number','amount'];
}
