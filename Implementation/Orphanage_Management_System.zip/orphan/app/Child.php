<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;


class Child extends Model
{
	use Sluggable;


	protected $fillable=['child_name','child_age','child_height','child_color','child_weight','child_image','child_info','child_status'];

	public function adapt(){
        return $this->hasMany('App\Adapt');
    }

     public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'child_name'
            ]
        ];
    }
}
